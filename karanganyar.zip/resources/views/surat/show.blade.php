<div class="layout">
    <div class="row">

        <embed type="application/pdf" src="{{  $surat->attachment()->first()->url() }}" width="100%" height="1208>

        </embed>

    </div>
</div>
