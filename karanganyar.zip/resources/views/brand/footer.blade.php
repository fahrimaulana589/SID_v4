<p class="small m-n">
    © Copyright {{date('Y')}} Desa Karanganyar
</p>
