@push('head')
    <link
        href="/favicon.ico"
        id="favicon"
        rel="icon"
    >
@endpush

<p class="h2 n-m font-thin v-center">

    <span class="m-l d-none d-sm-block">
        Karanganyar
        <small class="v-top opacity">SID</small>
    </span>
</p>
